/*
 * RPF_neutron_PID.cpp
 *
 *   Edited by: Dang coi - Oct 15, 2024
 *   Adapted for Arduino by: ChatGPT
 */

#include "RPF_neutron_PID.h"

// Khởi tạo các trọng số mạng RBF (Radial Basis Function)
void initializeWeights()
{
  // Khởi tạo trọng số cho mỗi neuron
  weights[0][0] = 2.0; // Trọng số cho Kp từ neuron 1
  weights[0][1] = 1.5; // Trọng số cho Ki từ neuron 1
  weights[0][2] = 0.5; // Trọng số cho Kd từ neuron 1

  weights[1][0] = 1.5; // Trọng số cho Kp từ neuron 2
  weights[1][1] = 0.9; // Trọng số cho Ki từ neuron 2
  weights[1][2] = 0.4; // Trọng số cho Kd từ neuron 2

  weights[2][0] = 1.0; // Trọng số cho Kp từ neuron 3
  weights[2][1] = 0.5; // Trọng số cho Ki từ neuron 3
  weights[2][2] = 0.3; // Trọng số cho Kd từ neuron 3
}

// Tính toán giá trị PID từ mạng RBF với sai số đầu vào e (error)
void computePIDRBF(double e)
{
  double phi[NUM_NEURONS]; // Mảng chứa giá trị Gaussian cho mỗi neuron
  double totalPhi = 0;     // Tổng giá trị phi để chuẩn hóa

  // Tính toán giá trị Gaussian phi[i] cho mỗi neuron dựa trên error e
  for (int i = 0; i < NUM_NEURONS; i++)
  {
    phi[i] = exp(-pow(e - mu[i], 2) / (2 * pow(sigma[i], 2))); // Hàm Gaussian
    totalPhi += phi[i];                                        // Cộng dồn để chuẩn hóa
  }

  // Reset giá trị Kp, Ki, Kd
  Kp = 0;
  Ki = 0;
  Kd = 0;

  // Tính toán giá trị Kp, Ki, Kd từ mạng RBF nếu totalPhi > 0 để tránh chia cho 0
  if (totalPhi > 0)
  {
    for (int i = 0; i < NUM_NEURONS; i++)
    {
      Kp += (phi[i] / totalPhi) * weights[i][0]; // Tính Kp dựa trên phi và trọng số
      Ki += (phi[i] / totalPhi) * weights[i][1]; // Tính Ki dựa trên phi và trọng số
      Kd += (phi[i] / totalPhi) * weights[i][2]; // Tính Kd dựa trên phi và trọng số
    }
  }
}
