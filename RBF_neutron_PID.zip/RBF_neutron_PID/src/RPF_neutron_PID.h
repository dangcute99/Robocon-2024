/*
 * RPF_neutron_PID.cpp
 *
 *   Edited by: Dang coi - Oct 15, 2024
 *   Adapted for Arduino by: ChatGPT
 */
#ifndef RPF_NEUTRON_PID_H
#define RPF_NEUTRON_PID_H

#include <math.h>

// Số lượng neuron trong mạng RBF
#define NUM_NEURONS 3

// Khai báo biến trọng số cho mạng RBF
extern double weights[NUM_NEURONS][3];

// Khai báo các biến cho PID
extern double Kp;
extern double Ki;
extern double Kd;

// Khai báo các giá trị trung tâm và độ lệch chuẩn cho các neuron
extern double mu[NUM_NEURONS];
extern double sigma[NUM_NEURONS];

// Hàm khởi tạo trọng số mạng RBF
void initializeWeights();

// Hàm tính toán giá trị PID từ mạng RBF
void computePIDRBF(double e);

#endif // RPF_NEUTRON_PID_H
