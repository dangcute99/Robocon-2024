# RPF_neutron_PID

Thư viện này cung cấp một bộ điều khiển PID sử dụng mạng RBF (Radial Basis Function) cho Arduino. Thư viện này cho phép điều chỉnh các kênh động và cung cấp các chiến lược điều khiển tiên tiến cho các ứng dụng yêu cầu điều khiển chính xác.

## Cài đặt

1. Tải xuống tệp ZIP hoặc sao chép kho lưu trữ.
2. Mở Arduino IDE.
3. Đi tới **Sketch > Include Library > Add .ZIP Library...** và chọn tệp ZIP đã tải xuống.

## Sử dụng

Bao gồm thư viện trong sketch Arduino của bạn:

```cpp
#include <RPF_neutron_PID.h>
```
