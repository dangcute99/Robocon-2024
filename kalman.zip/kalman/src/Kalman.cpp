/*
 * kalman.cpp
 *
 *   Edited by: Dang coi - Oct 12, 2024
 *   Adapted for Arduino by: ChatGPT
 *   Supports dynamic channels (n channels)
 */

#include "kalman.h"

// Constructor: Initialize the Kalman filter with n channels
KalmanFilter::KalmanFilter(int num_channels)
{
  _num_channels = num_channels;

  // Dynamically allocate memory for each channel
  _err_measure = new float[_num_channels];
  _err_estimate = new float[_num_channels];
  _q = new float[_num_channels];
  _current_estimate = new float[_num_channels];
  _last_estimate = new float[_num_channels];
  _kalman_gain = new float[_num_channels];

  // Initialize all arrays
  for (int i = 0; i < _num_channels; i++)
  {
    _err_measure[i] = 0.0;
    _err_estimate[i] = 0.0;
    _q[i] = 0.0;
    _current_estimate[i] = 0.0;
    _last_estimate[i] = 0.0;
    _kalman_gain[i] = 0.0;
  }
}

// Destructor: Free allocated memory
KalmanFilter::~KalmanFilter()
{
  delete[] _err_measure;
  delete[] _err_estimate;
  delete[] _q;
  delete[] _current_estimate;
  delete[] _last_estimate;
  delete[] _kalman_gain;
}

// Initialize Kalman filter parameters for a specific channel
void KalmanFilter::MultiKalmanFilter(float mea_e, float est_e, float q, int channel)
{
  if (channel < _num_channels)
  {
    _err_measure[channel] = mea_e;
    _err_estimate[channel] = est_e;
    _q[channel] = q;
    _last_estimate[channel] = 0.0; // Initialize the last estimate to 0
    _current_estimate[channel] = 0.0;
    _kalman_gain[channel] = 0.0;
  }
}

// Update the estimate with a new measurement for a specific channel
float KalmanFilter::updateEstimate(float mea, int channel)
{
  if (channel < _num_channels)
  {
    _kalman_gain[channel] = _err_estimate[channel] / (_err_estimate[channel] + _err_measure[channel]);
    _current_estimate[channel] = _last_estimate[channel] + _kalman_gain[channel] * (mea - _last_estimate[channel]);
    _err_estimate[channel] = (1.0 - _kalman_gain[channel]) * _err_estimate[channel] +
                             fabs(_last_estimate[channel] - _current_estimate[channel]) * _q[channel];
    _last_estimate[channel] = _current_estimate[channel];
    return _current_estimate[channel];
  }
  return 0; // Return 0 if channel is out of bounds
}

// Set the measurement error for a specific channel
void KalmanFilter::setMeasurementError(float mea_e, int channel)
{
  if (channel < _num_channels)
  {
    _err_measure[channel] = mea_e;
  }
}

// Set the estimate error for a specific channel
void KalmanFilter::setEstimateError(float est_e, int channel)
{
  if (channel < _num_channels)
  {
    _err_estimate[channel] = est_e;
  }
}

// Set the process noise for a specific channel
void KalmanFilter::setProcessNoise(float q, int channel)
{
  if (channel < _num_channels)
  {
    _q[channel] = q;
  }
}

// Get the current Kalman gain for a specific channel
float KalmanFilter::getKalmanGain(int channel)
{
  if (channel < _num_channels)
  {
    return _kalman_gain[channel];
  }
  return 0; // Return 0 if channel is out of bounds
}

// Get the current estimate error for a specific channel
float KalmanFilter::getEstimateError(int channel)
{
  if (channel < _num_channels)
  {
    return _err_estimate[channel];
  }
  return 0; // Return 0 if channel is out of bounds
}
