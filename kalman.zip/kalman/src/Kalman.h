/*
 * kalman.h
 *
 *   Edited by: Dang coi - Oct 12, 2024
 *   Adapted for Arduino by: ChatGPT
 *   Supports dynamic channels (n channels)
 */

#ifndef __KALMAN_H
#define __KALMAN_H

#include <Arduino.h>
#include <math.h>

// Define a KalmanFilter class to manage dynamic channels
class KalmanFilter
{
private:
  float *_err_measure;
  float *_err_estimate;
  float *_q;
  float *_current_estimate;
  float *_last_estimate;
  float *_kalman_gain;
  int _num_channels; // Number of channels (dynamic)

public:
  // Constructor: Initialize the Kalman filter with n channels
  KalmanFilter(int num_channels);

  // Destructor: Free allocated memory
  ~KalmanFilter();

  // Initialize Kalman filter parameters for a specific channel
  void MultiKalmanFilter(float mea_e, float est_e, float q, int channel);

  // Update the estimate with a new measurement for a specific channel
  float updateEstimate(float mea, int channel);

  // Set the measurement error for a specific channel
  void setMeasurementError(float mea_e, int channel);

  // Set the estimate error for a specific channel
  void setEstimateError(float est_e, int channel);

  // Set the process noise for a specific channel
  void setProcessNoise(float q, int channel);

  // Get the current Kalman gain for a specific channel
  float getKalmanGain(int channel);

  // Get the current estimate error for a specific channel
  float getEstimateError(int channel);
};

#endif /* __KALMAN_H */
