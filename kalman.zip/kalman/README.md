# Kalman Filter for Arduino

This library provides a simple Kalman Filter implementation for smoothing sensor data in real-time. It is useful for any sensors that produce noisy data such as ADC readings.

## Installation

1. Download the ZIP file or clone the repository.
2. Open Arduino IDE.
3. Go to **Sketch > Include Library > Add .ZIP Library...** and select the downloaded ZIP file.

## Usage

Include the library in your Arduino sketch:

```cpp
#include <Kalman.h>
```
